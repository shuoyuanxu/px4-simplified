clear all
clc
close all

T = [0;
1200;
1750;
2120;
2650;
2850] / 1000 * 9.81

RPM = [
0;
4050;
4850;
5400;
5850;
6250]

t1= (0: 100: 6000) / 1000 * 9.81
p = polyfit(T, RPM, 4)
RPMp = polyval(p, t1)
RPMp1 = polyval(p, T)
s = RPMp1-RPM
hFig1 = figure(1);
hold all
% plot([X X X],[coarse medium fine])

plot(T, RPM,'-r+','LineWidth', 0.7,'linewidth',2)
plot(t1, RPMp,'--bs','LineWidth', 0.7,'MarkerSize',5,'linewidth',2)

xlabel('Thrust')
ylabel('RPM')
legend('RPM','Prediction','Fine','Location','SouthWest')
title('Motor Model')
grid on;

hFig2 = figure(2);
hold all
% plot([X X X],[coarse medium fine])

plot(T, s,'-r+','LineWidth', 0.7,'linewidth',2)
title('Motor Model error')
grid on;